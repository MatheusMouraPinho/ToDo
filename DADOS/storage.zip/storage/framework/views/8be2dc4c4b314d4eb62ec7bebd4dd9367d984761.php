<?php echo e($slot); ?>

<?php /**PATH /home/vol1000_4/epizy.com/epiz_26019148/htdocs/ToDo/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>