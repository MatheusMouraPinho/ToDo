@extends('layouts.LR')


@section('content')
<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-50">
				<form class="login100-form validate-form">
                <div class="login100-form-title p-b-33">Aviso</div>

                    <div>
                        Olá! Percebemos que você esta utilizando o internet explorer o que pode ocasionar em erros visuais no site, 
                        para acessar o site utilize um navegador mais atualizado.
                        <br><br>
                    </div>
				</form>
			</div>
		</div>
	</div>
@endsection