@extends('layouts.LR')


@section('content')
<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-50">
				<form class="login100-form validate-form">
                <div class="login100-form-title p-b-33">Aviso</div>

                    <div>
                    Olá! percebemos que você esta utilizando um dispositivo Mobile porem o nosso site
                    ainda não esta 100% responsivo por enquanto. <a href="http://todoideias.gq/login">Continuar mesmo assim</a>
                        <br><br>
                    </div>
				</form>
			</div>
		</div>
	</div>
@endsection
