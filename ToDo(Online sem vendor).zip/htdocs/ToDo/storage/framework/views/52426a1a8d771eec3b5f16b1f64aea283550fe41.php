<?php echo e($slot); ?>

<?php /**PATH /home/vol13_3/epizy.com/epiz_26032563/htdocs/ToDo/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>