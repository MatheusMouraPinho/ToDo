<?php $__env->startComponent('mail::message'); ?>
Olá,  
O sua conta foi deletada devido a decisão do administrador,  
entre em contato com algum administrador para mais detalhes.

Agradecemos pela sua compreensão,  
Repositorio de Ideias ToDo.
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH /home/vol13_3/epizy.com/epiz_26032563/htdocs/ToDo/resources/views/mail/deletado.blade.php ENDPATH**/ ?>