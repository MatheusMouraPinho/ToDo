<?php if($rows['id_categoria'] == '1' ){ $categoria = "Web, Mobile & Software"; }elseif($rows['id_categoria'] == "2"){ $categoria = "Design & Criação"; }elseif($rows['id_categoria'] == "3"){$categoria = "Engenharia & Arquitetura";
}elseif($rows['id_categoria'] == "4"){$categoria = "Marketing";}elseif($rows['id_categoria'] == "5"){$categoria = "Outros";}else{$categoria = "Sem categoria";}?>

<?php
    $nivel = Auth::user()->nivel;
    $id_nivel = 0; 
    if($nivel >= 2){$id_nivel = 1;}
?>

<!-- Área de detalhes de ideias postadas -->

<div class="painel-dados">
    <div class="modal fade id" id="post<?php echo $id_post ?>" role="dialog">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <div class="modal-body">
            <div class="popup-title">
              <span class="popup_sub bold">Título:</span>
              <p class="popup_cont"><?php echo $rows['titulo_postagem']; ?></p>
            </div>
            <div class="popup_desc">
              <span style="vertical-align: top" class="popup_sub bold">Descrição:</span>
              <textarea id="popup_cont_desc" cols="70" rows="5" disabled><?php echo $rows['descricao_postagem']; ?></textarea>
            </div>
            <div>
              <span class="popup_sub bold">Categoria:</span>
              <p class="popup_coment"><?php echo $categoria ?></p>
            </div>
            <?php
              $nome_file = "../public/storage/posts/".'1'.$id_post.Str::kebab($rows['titulo_postagem']).'.jpeg';
              $nome_file_png = "../public/storage/posts/".'1'.$id_post.Str::kebab($rows['titulo_postagem']).'.png';
              $nome_file2 = "../public/storage/posts/".'2'.$id_post.Str::kebab($rows['titulo_postagem']).'.jpeg';
              $nome_file_png2 = "../public/storage/posts/".'2'.$id_post.Str::kebab($rows['titulo_postagem']).'.png';
              $nome_file3 = "../public/storage/posts/".'3'.$id_post.Str::kebab($rows['titulo_postagem']).'.jpeg';
              $nome_file_png3 = "../public/storage/posts/".'3'.$id_post.Str::kebab($rows['titulo_postagem']).'.png';
            ?>
            <div class="popup_img">
              <span class="popup_sub bold">Imagens:</span>
              <?php if(file_exists($nome_file)): ?>
                <img class="popup_imgs" id="img_post" data-toggle="modal" data-target="#img1<?php echo $id_post ?>" src="<?php echo e(url('storage/posts/'.'1'.$id_post.Str::kebab($rows['titulo_postagem']).'.jpeg')); ?>">
              <?php elseif(file_exists($nome_file_png)): ?>
                <img class="popup_imgs" id="img_post" data-toggle="modal" data-target="#img1<?php echo $id_post ?>" src="<?php echo e(url('storage/posts/'.'1'.$id_post.Str::kebab($rows['titulo_postagem']).'.png')); ?>">
              <?php else: ?>
                <img class="popup_imgs_null" src="<?php echo e(asset('img/semimagem.jpg')); ?>">
              <?php endif; ?>
              <?php if(file_exists($nome_file2)): ?>
                <img class="popup_imgs" id="img_post" data-toggle="modal" data-target="#img2<?php echo $id_post ?>" src="<?php echo e(url('storage/posts/'.'2'.$id_post.Str::kebab($rows['titulo_postagem']).'.jpeg')); ?>">
              <?php elseif(file_exists($nome_file_png2)): ?>
                <img class="popup_imgs" id="img_post" data-toggle="modal" data-target="#img2<?php echo $id_post ?>" src="<?php echo e(url('storage/posts/'.'2'.$id_post.Str::kebab($rows['titulo_postagem']).'.png')); ?>">
              <?php else: ?>
                <img class="popup_imgs_null" src="<?php echo e(asset('img/semimagem.jpg')); ?>">
              <?php endif; ?>
              <?php if(file_exists($nome_file3)): ?>
                <img class="popup_imgs" id="img_post" data-toggle="modal" data-target="#img3<?php echo $id_post ?>" src="<?php echo e(url('storage/posts/'.'3'.$id_post.Str::kebab($rows['titulo_postagem']).'.jpeg')); ?>">
              <?php elseif(file_exists($nome_file_png3)): ?>
                <img class="popup_imgs" id="img_post" data-toggle="modal" data-target="#img3<?php echo $id_post ?>" src="<?php echo e(url('storage/posts/'.'3'.$id_post.Str::kebab($rows['titulo_postagem']).'.png')); ?>">
              <?php else: ?>
                <img class="popup_imgs_null" src="<?php echo e(asset('img/semimagem.jpg')); ?>">
              <?php endif; ?>
            </div>
            <div class="popup_aval">
              <span class="popup_sub bold">Avaliação:</span>
              <?php if(!empty($post['avaliacao'][0])): ?> <!--  Verifica se a consulta sql de avaliações retorna algum valor  -->
                <?php for($c=0; $c<sizeof($post['avaliacao']); $c++): ?> <!-- enquanto a variável c não tiver o valor igualado ao tamanho do array de avaliação, uma avaliação por vez é mostrada -->
                  <?php if($post['avaliacao'][$c]->id_postagem == $id_post): ?>  <!-- Mas a avaliação só é mostrada caso o id da postagem da avaliação for igual ao da postagem que está sendo visualizada -->
                    <p class="popup_avali">
                      <span class="bold">Inovação: </span><?php echo e($post['avaliacao'][$c]->inovacao_avaliacao); ?>

                    </p>
                    <p class="popup_avali">
                      <span class="bold">Potencial: </span><?php echo e($post['avaliacao'][$c]->potencial_avaliacao); ?>

                    </p>
                    <p class="popup_avali">
                      <span class="bold">Complexidade: </span><?php echo e($post['avaliacao'][$c]->complexidade_avaliacao); ?>

                    </p>
                    <div class="popup_coment_aval" id="avaliacao">
                      <div class="header-coment">
                        <?php if($post['avaliador'][$c]->img_usuarios === null): ?>
                            <img class="img-dados-coment" src="<?php echo e(asset('img/semuser.png')); ?>">
                          <?php else: ?>
                            <img  alt="<?php echo e($post['avaliador'][$c]->img_usuarios); ?>" name="img_usuarios" class="img-dados-coment" src="<?php echo e(asset('/storage/users/'.$post['avaliador'][$c]->img_usuarios)); ?>">
                          <?php endif; ?>
                          <form id="perfil" action="<?php echo e(route('perfil')); ?>" method="get">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id_usuario" value="<?php echo e($post['avaliador'][$c]->id); ?>">
                            <input class="bold user" type="submit" value="<?php echo e($post['avaliador'][$c]->usuario); ?>">
                          </form>
                        <span class="underline data-coment" style="margin-right: 10px"><?php echo e(Helper::tempo_corrido($post['avaliacao'][$c]->data_comentarios)); ?></span>
                      </div>
                      
                      <p class="conteudo-coment text-justify"><?php echo e($post['avaliacao'][$c]->conteudo_comentarios); ?></p>
                      <div class="footer-coment">
                        <?php $resultados = Helper::verifica_like_coment($post['avaliacao'][$c]->id_comentarios)?>
                          <?php if($resultados == 0): ?>
                            <span href="#" id="btn_like" class="curtir fa-thumbs-o-up fa" data-id="<?php echo e($post['avaliacao'][$c]->id_comentarios); ?>"></span> 
                            <span class="likes" id="likes_<?php echo e($post['avaliacao'][$c]->id_comentarios); ?>"><?php echo e($post['avaliacao'][$c]->likes_comentarios); ?></span>
                          <?php else: ?> 
                          <span href="#" id="btn_like" class="curtir fa-thumbs-up fa" data-id="<?php echo e($post['avaliacao'][$c]->id_comentarios); ?>"></span>
                          <span class="likes" id="likes_<?php echo e($post['avaliacao'][$c]->id_comentarios); ?>"><?php echo e($post['avaliacao'][$c]->likes_comentarios); ?></span>
                          <?php endif; ?>
                      </div>
                    </div>
                  <?php endif; ?>

                  <!-- Verifica se a avaliação está pendente ou não -->
                  <!-- Quando o for rodar todas as vezes e tbm todos questionamentos do if, e o cont não for igual ao tamanho de quantidade de avaliações , quer dizer q existe alguma avaliação que pertence a postagem atual, e portanto não está pendente -->
                  <?php $cont = 0;?>
                  <?php for($d=0;$d<sizeof($post['avaliacao']);$d++): ?>
                    <?php if($post['avaliacao'][$d]->id_postagem != $id_post): ?>  
                      <?php 
                        $cont+= 1 ;
                      ?>
                    <?php endif; ?>
                  <?php endfor; ?>
                <?php endfor; ?>
                <?php if($cont === sizeof($post['avaliacao'])): ?>
                  <?php if($id_nivel == 1 && isset($rows['id']) && $user_post != $user): ?>
                    <a href="#" class="popup_coment" data-toggle="modal" data-target="#post<?php echo $id_post ?>_avaliar">Avaliar postagem</a>
                  <?php else: ?>
                    <p class="popup_coment">Pendente</p>
                  <?php endif; ?>
                <?php endif; ?>
              <?php else: ?>
                <?php if($id_nivel == 1 && isset($rows['id']) && $user_post != $user): ?>
                  <a href="#" class="popup_coment" data-toggle="modal" data-target="#post<?php echo $id_post ?>_avaliar">Avaliar postagem</a>
                <?php else: ?>
                  <p class="popup_coment">Pendente</p>
                <?php endif; ?>
              <?php endif; ?>
              
            </div>
            <div class="popup-aval">
              <span class="popup_sub bold">Comentários:</span>   
              <div style="margin-bottom: 15%">
                <form action="<?php echo e(route('comentario')); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <textarea required name="conteudo_comentarios" class="comentario" maxlength="255" cols="60" rows="2" placeholder="Digite aqui seu comentário"></textarea>
                  <input type="hidden" name="id_postagem" value="<?php echo e($id_post); ?>">
                  <input type="submit" name="comentario" class="btn btn-primary button_coment" value="Enviar">
                </form>
              </div>
              <?php if(!empty($post['comentarios'][0])): ?>  
                <?php for($f=0; $f<sizeof($post['comentarios']); $f++): ?>
                  <?php if($post['comentarios'][$f]->id_postagem == $id_post): ?>
                    <hr>
                    <div class="popup_coment_aval" id="id_comentario<?php echo e($post['comentarios'][$f]->id_comentarios); ?>">
                      <div class="header-coment">
                        <?php if($post['comentarios'][$f]->img_usuarios === null): ?>
                          <img class="img-dados-coment" src="<?php echo e(asset('img/semuser.png')); ?>">
                        <?php else: ?>
                          <img  alt="<?php echo e($post['comentarios'][$f]->img_usuarios); ?>" name="img_usuarios" class="img-dados-coment" src="<?php echo e(asset('/storage/users/'.$post['comentarios'][$f]->img_usuarios)); ?>">
                        <?php endif; ?>
                        <form id="perfil" action="<?php echo e(route('perfil')); ?>" method="get">
                          <?php echo csrf_field(); ?>
                          <input type="hidden" name="id_usuario" value="<?php echo e($post['comentarios'][$f]->id); ?>">
                          <input class="bold user" type="submit" value="<?php echo e($post['comentarios'][$f]->usuario); ?>">
                        </form>
                        <div class="dropdown dropdown1">

                          <!--Trigger-->
                         
                          <a class="btn-floating btn-lg "type="button" id="dropdownMenu2" data-toggle="dropdown"
                          aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
                        
                        
                          <!--Menu-->
                          <div class="dropdown-menu dropdown-primary">
                            <?php if($post['comentarios'][$f]->id === Auth::user()->id): ?>
                              <a id="edit" class="dropdown-item" href="#" style="cursor: pointer" data-toggle="modal" data-target="#popup<?php echo e($post['comentarios'][$f]->id_comentarios); ?>_edit1">Editar</a>
                              <a class="dropdown-item" href="#" style="cursor: pointer" data-toggle="modal" data-target="#popup<?php echo e($post['comentarios'][$f]->id_comentarios); ?>_apagar2">Apagar</a>
                            <?php else: ?>
                              <a class="dropdown-item" href="#" style="cursor: pointer" data-toggle="modal" data-target="#den_comen<?php echo e($post['comentarios'][$f]->id_comentarios); ?>">Denunciar</a>
                            <?php endif; ?>
                          </div>
                        </div>
                        <!-- Modal denunciar comentario -->
                        <div class="modal fade id" id="den_comen<?php echo e($post['comentarios'][$f]->id_comentarios); ?>" role="dialog">
                            <div class="modal-dialog modal-content">
                                <div class="modal-header"></div>
                                <form action="/denunciar_comentario" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-body">
                                        <h3><p>Denunciar Comentario por:</p></h3><br>
                                        <h6>
                                            <label class="radio-custom">Conteúdo Inadequado
                                                <input type="radio" id="radio1" type="radio" name="option" value="3" required>
                                                <span class="checkmark"></span>
                                            </label>
                                            <label class="radio-custom">Spam
                                                <input type="radio" id="radio3" type="radio" name="option" value="1" required>
                                                <span class="checkmark"></span>
                                            </label>
                                            <label class="radio-custom">Copia
                                                <input type="radio" id="radio3" type="radio" name="option" value="2" required>
                                                <span class="checkmark"></span>
                                            </label>
                                        </h6>
                                        <input type="hidden" value="<?php echo e($id_post); ?>" name="id_postagem">
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
                                            <input name="id_comentario" type="hidden" value="<?php echo e($post['comentarios'][$f]->id_comentarios); ?>">
                                            <input name="id_usuario" type="hidden" value="<?php echo $user;?>">
                                            <input data-toggle="modal" type="submit" class="btn btn-primary" value="Confirmar">
                                        </div> 
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- FIM Modal denunciar comentario -->
                        <?php if(empty($post['comentarios'][$f]->edit_comentarios)): ?>
                          <span class="underline data-coment"><?php echo e(Helper::tempo_corrido($post['comentarios'][$f]->data_comentarios)); ?></span>
                        <?php else: ?>
                          <span class="underline data-coment"><?='(editado) '. Helper::tempo_corrido($post['comentarios'][$f]->data_comentarios)?></span>
                        <?php endif; ?>
                      </div>
                      <p class="conteudo-coment text-justify"><?php echo e($post['comentarios'][$f]->conteudo_comentarios); ?></p>
                      <div class="footer-coment">
                        <span class="mostrar">Responder</span>
                        <?php $resultados = Helper::verifica_like_coment($post['comentarios'][$f]->id_comentarios);$id_comentario = $post['comentarios'][$f]->id_comentarios;?>
                          <?php if($resultados == 0): ?>
                            <span href="#" id="btn_like" class="curtir fa-thumbs-o-up fa" data-id="<?php echo e($post['comentarios'][$f]->id_comentarios); ?>"></span> 
                            <span class="likes" id="likes_<?php echo e($post['comentarios'][$f]->id_comentarios); ?>"><?php echo e($post['comentarios'][$f]->likes_comentarios); ?></span>
                          <?php else: ?> 
                          <span href="#" id="btn_like" class="curtir fa-thumbs-up fa" data-id="<?php echo e($post['comentarios'][$f]->id_comentarios); ?>"></span>
                          <span class="likes" id="likes_<?php echo e($post['comentarios'][$f]->id_comentarios); ?>"><?php echo e($post['comentarios'][$f]->likes_comentarios); ?></span>
                          <?php endif; ?>

                        <!--  Modal de edição de comentários -->
                          <div class="painel-dados">
                            <div class="modal fade id" id="popup<?php echo e($post['comentarios'][$f]->id_comentarios); ?>_edit1" role="dialog">
                              <div class="modal-dialog">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                  </div>
                                  <div class="modal-body"> 
                                    <form action="<?php echo e(route('edit.coment')); ?>" method="POST"> 
                                      <?php echo csrf_field(); ?>                   
                                      <div class="popup-title">
                                        <label style="vertical-align: top" for="editcomentario" class="bold subdados">Descrição:</label>
                                        <textarea name="editcomentario" id="edit_desc" cols="60" rows="1"><?php echo e($post['comentarios'][$f]->conteudo_comentarios); ?></textarea>
                                        <input type="hidden" name="id_coment" value="<?php echo e($post['comentarios'][$f]->id_comentarios); ?>">
                                        <input type="hidden" value="<?php echo e($id_post); ?>" name="id_postagem">
                                      </div>
                                    

                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
                                      <input data-toggle="modal" data-target="#hiddenDiv" type="submit" class="btn btn-primary dropright" value="Salvar Alterações">
                                      
                                    </div> 
                                  </form> 

                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                  
                        <div id="comentarios">
                          <form action="<?php echo e(route('comentario')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input name="conteudo" maxlength="255" style="width: 100%" type="text" class="btn-popup mr-sm-2" placeholder="<?='Em resposta a '.'@'. $post['comentarios'][$f]->usuario?>">
                            <input type="hidden" name="id_coment" value="<?php echo e($post['comentarios'][$f]->id_comentarios); ?>">
                            <input type="hidden" name="id_postagem" value="<?php echo e($id_post); ?>">
                            <input type="hidden" name="id_mencionado" value="<?php echo e($post['comentarios'][$f]->id); ?>">
                            <input type="submit" style="display: none" name="respostas">
                          </form>
                        </div>
                      </div>
                      
                    </div> 
                    
                    <!--  Modal para apagar comentários -->
                  <div class="painel-dados">
                    <div class="modal fade id" id="popup<?php echo e($post['comentarios'][$f]->id_comentarios); ?>_apagar2" role="dialog">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header">
                          </div>
                          <div class="modal-body"> 
                            <p>Deseja realmente apagar este comentário?</p>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
                              <form action="<?php echo e(route('apagar-coment')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input name="id_comentario" type="hidden" value="<?php echo e($post['comentarios'][$f]->id_comentarios); ?>">
                                <input type="hidden" value="<?php echo e($id_post); ?>" name="id_postagem">
                                <input data-toggle="modal" type="submit" class="btn btn-primary dropright" value="Apagar comentário">
                              </form>
                            </div> 
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>         
                  <?php endif; ?>
                  <?php for($g=0; $g<sizeof($post['reply_coment']); $g++): ?>
                    <?php if($post['reply_coment'][$g]->id_postagem == $id_post && $post['comentarios'][$f]->id_comentarios === $post['reply_coment'][$g]->id_comentarios_ref): ?>
                      <div class="popup_coment_aval" id="respostas" style="margin-top: 10px; width: 95%;margin-left:5%">
                        
                        <div class="header-coment">
                          <div class="dropdown dropdown1">

                            <!--Trigger-->
                           
                            <a class="btn-floating btn-lg black"type="button" id="dropdownMenu3" data-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
                          
                          
                            <!--Menu-->
                            <div class="dropdown-menu dropdown-primary">
                              <?php if($post['reply_coment'][$g]->id === Auth::user()->id): ?>
                                <a class="dropdown-item" data-toggle="modal" style="cursor: pointer" data-target="#popup<?php echo e($post['reply_coment'][$g]->id_comentarios); ?>_edit">Editar</a>
                                <a class="dropdown-item" style="cursor: pointer" data-toggle="modal" data-target="#popup<?php echo e($post['reply_coment'][$g]->id_comentarios); ?>_apagar1">Apagar</a>
                              <?php else: ?>
                                <a class="dropdown-item" href="#" style="cursor: pointer" data-toggle="modal" data-target="#den_comen_reply<?php echo e($post['reply_coment'][$g]->id_comentarios); ?>">Denunciar</a>
                              <?php endif; ?>
                            </div>
                          </div>
                          <!-- Modal denunciar comentario Reply -->
                          <div class="modal fade id" id="den_comen_reply<?php echo e($post['reply_coment'][$g]->id_comentarios); ?>" role="dialog">
                              <div class="modal-dialog modal-content">
                                  <div class="modal-header"></div>
                                  <form action="/denunciar_comentario" method="POST">
                                      <?php echo csrf_field(); ?>
                                      <div class="modal-body">
                                          <h3><p>Denunciar Comentario por:</p></h3><br>
                                          <h6>
                                              <label class="radio-custom">Conteúdo Inadequado
                                                  <input type="radio" id="radio1" type="radio" name="option" value="3" required>
                                                  <span class="checkmark"></span>
                                              </label>
                                              <label class="radio-custom">Spam
                                                  <input type="radio" id="radio3" type="radio" name="option" value="1" required>
                                                  <span class="checkmark"></span>
                                              </label>
                                              <label class="radio-custom">Copia
                                                  <input type="radio" id="radio3" type="radio" name="option" value="2" required>
                                                  <span class="checkmark"></span>
                                              </label>
                                          </h6>
                                          <input type="hidden" value="<?php echo e($id_post); ?>" name="id_postagem">
                                          <div class="modal-footer">
                                              <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
                                              <input name="id_comentario" type="hidden" value="<?php echo e($post['reply_coment'][$g]->id_comentarios); ?>">
                                              <input name="id_usuario" type="hidden" value="<?php echo $user;?>">
                                              <input data-toggle="modal" type="submit" class="btn btn-primary" value="Confirmar">
                                          </div> 
                                      </div>
                                  </form>
                              </div>
                          </div>
                          <!-- FIM Modal denunciar comentario reply -->
                          <?php if(empty($post['reply_coment'][$g]->edit_comentarios)): ?>
                            <span class="underline data-coment"><?php echo e(Helper::tempo_corrido($post['reply_coment'][$g]->data_comentarios)); ?></span>
                          <?php else: ?>
                            <span class="underline data-coment"><?='(editado) '. Helper::tempo_corrido($post['reply_coment'][$g]->data_comentarios)?></span>
                          <?php endif; ?>
                          <div>
                            <?php if($post['reply_coment'][$g]->img_usuarios === null): ?>
                              <img class="img-dados-coment" src="<?php echo e(asset('img/semuser.png')); ?>">
                            <?php else: ?>
                              <img alt="<?php echo e($post['reply_coment'][$g]->img_usuarios); ?>" name="img_usuarios" class="img-dados-coment" src="<?php echo e(asset('/storage/users/'.$post['reply_coment'][$g]->img_usuarios)); ?>">
                            <?php endif; ?>
                            <form id="perfil" action="<?php echo e(route('perfil')); ?>" method="get">
                              <?php echo csrf_field(); ?>
                              <input type="hidden" name="id_usuario" value="<?php echo e($post['reply_coment'][$g]->id); ?>">
                              <input alt="" class="bold user" type="submit" value="<?php echo e($post['reply_coment'][$g]->usuario); ?>">
                            </form>
                          </div>
                          
                        </div>
                        <?php for($k=0; $k<sizeof($post['mencionado']);$k++): ?>
                          <?php if($post['mencionado'][$k]->id_comentarios === $post['reply_coment'][$g]->id_comentarios): ?>
                            <form id="perfil" action="<?php echo e(route('perfil')); ?>" method="get">
                              <?php echo csrf_field(); ?>
                              <input type="hidden" name="id_usuario" value="<?php echo e($post['mencionado'][$k]->id); ?>">
                              <input class="mencionado" type="submit" value="<?php echo e('@'. $post['mencionado'][$k]->usuario); ?>">
                            </form>
                          <?php endif; ?>
                        <?php endfor; ?>
                        <p class="conteudo-coment"><?php echo e($post['reply_coment'][$g]->conteudo_comentarios); ?></p>
                      
                        <div class="footer-coment">
                          <span class="mostrar">Responder</span>
                          <?php $resultados = Helper::verifica_like_coment($post['reply_coment'][$g]->id_comentarios)?>
                          <?php if($resultados == 0): ?>
                            <span href="#" id="<?php echo e($post['reply_coment'][$g]->id_comentarios); ?>" class="curtir fa-thumbs-o-up fa" data-id="<?php echo e($post['reply_coment'][$g]->id_comentarios); ?>"></span> 
                            <span class="likes" id="likes_<?php echo e($post['reply_coment'][$g]->id_comentarios); ?>"><?php echo e($post['reply_coment'][$g]->likes_comentarios); ?></span>
                          <?php else: ?> 
                            <span href="#" id="<?php echo e($post['reply_coment'][$g]->id_comentarios); ?>" class="curtir fa-thumbs-up fa" data-id="<?php echo e($post['reply_coment'][$g]->id_comentarios); ?>"></span>
                            <span class="likes" id="likes_<?php echo e($post['reply_coment'][$g]->id_comentarios); ?>"><?php echo e($post['reply_coment'][$g]->likes_comentarios); ?></span>
                          <?php endif; ?>
                          <div id="comentarios">
                            <form action="<?php echo e(route('comentario')); ?>" method="POST">
                              <?php echo csrf_field(); ?>
                              <input name="conteudo" maxlength="255" style="width: 100%" type="text" class="btn-popup mr-sm-2" placeholder="<?='Em resposta a '.'@'. $post['reply_coment'][$g]->usuario?>">
                              <input type="hidden" name="id_coment" value="<?php echo e($post['comentarios'][$f]->id_comentarios); ?>">
                              <input type="hidden" name="id_postagem" value="<?php echo e($id_post); ?>">
                              <input type="hidden" name="id_mencionado" value="<?php echo e($post['reply_coment'][$g]->id); ?>">
                              <input type="submit" style="display: none" name="respostas">
                            </form>
                          </div>
                        </div>

                      </div>

                      <!--  Modal de edição de respostas de comentários -->
                      <div class="painel-dados">
                        <div class="modal fade id" id="popup<?php echo e($post['reply_coment'][$g]->id_comentarios); ?>_edit" role="dialog">
                          <div class="modal-dialog">
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                              </div>
                              <div class="modal-body"> 
                                <form action="<?php echo e(route('edit.coment')); ?>" method="POST"> 
                                  <?php echo csrf_field(); ?>                   
                                  <div class="popup-title">
                                    <label style="vertical-align: top" for="editcomentario" class="bold subdados">Descrição:</label>
                                    <textarea name="editcomentario" id="edit_desc" cols="60" rows="1"><?php echo e($post['reply_coment'][$g]->conteudo_comentarios); ?></textarea>
                                    <input type="hidden" name="id_coment" value="<?php echo e($post['reply_coment'][$g]->id_comentarios); ?>">
                                    <input type="hidden" value="<?php echo e($id_post); ?>" name="id_postagem">
                                  </div>
                                

                                <div class="modal-footer">
                                  <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
                                  <input data-toggle="modal" data-target="#hiddenDiv" type="submit" class="btn btn-primary dropright" value="Salvar Alterações">
                                  
                                </div> 
                              </form> 

                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      <!--  Modal para apagar subcomentários -->
                      <div class="painel-dados">
                        <div class="modal fade id" id="popup<?php echo e($post['reply_coment'][$g]->id_comentarios); ?>_apagar1" role="dialog">
                          <div class="modal-dialog">
                            <div class="modal-content">
                              <div class="modal-header">
                              </div>
                              <div class="modal-body"> 
                                <p>Deseja realmente apagar este comentário?</p>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
                                  <form action="<?php echo e(route('apagar-coment')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input name="id_comentario" type="hidden" value="<?php echo e($post['reply_coment'][$g]->id_comentarios); ?>">
                                    <input data-toggle="modal" type="submit" class="btn btn-primary dropright" value="Apagar comentário">
                                    <input type="hidden" value="<?php echo e($id_post); ?>" name="id_postagem">
                                  </form>
                                </div> 
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    <?php endif; ?>
                  <?php endfor; ?>                
                <?php endfor; ?>
              <?php endif; ?>
            </div>           
            <div class="modal-footer" style="margin-top: 10px">
              <div class="popup-like">
                <img width="30px" src="<?php echo e(asset('img/like.png')); ?>">
                <p class="num-like"><?php echo $rows['likes_postagem']; ?></p>
              </div>  
              <p class="data-post">
                Postado em <?php echo date('d/m/Y', strtotime($rows['data_postagem'])); ?> às  <?php echo date('H:i', strtotime($rows['data_postagem'])); ?> horas
              </p>       
            </div>
            </div>
        </div>
    </div>
</div>
</div>

<!-- Popup de visualização de imagens -->
<div class="popup_img_post">
  <div class="modal modal_img fade" id="img1<?php echo $id_post ?>" role="dialog">
      <button type="button" class="close btn_fechar" data-dismiss="modal">&times;</button>
    <div class="modal-dialog">
      <div class="modal-content modal_content">
          <div class="modal-body">
              <button type="button" class="close btn_fechar_body" data-dismiss="modal">&times;</button>
              <?php 
                  $nome_file = "../public/storage/posts/".'1'.$id_post.Str::kebab($rows['titulo_postagem']).'.jpeg';
                  $nome_file_png = "../public/storage/posts/".'1'.$id_post.Str::kebab($rows['titulo_postagem']).'.png';  
              ?>
              <?php if(file_exists($nome_file)): ?>
                  <img id="img_post1" src="<?php echo e(url('storage/posts/'.'1'.$id_post.Str::kebab($rows['titulo_postagem']).'.jpeg')); ?>">
              <?php elseif(file_exists($nome_file_png)): ?>
                  <img id="img_post1" src="<?php echo e(url('storage/posts/'.'1'.$id_post.Str::kebab($rows['titulo_postagem']).'.png')); ?>">
              <?php endif; ?>
          </div>
      </div>
    </div>
  </div>
</div>
<!-- Fim Popup de visualização de imagens -->

<!-- Popup de visualização de imagens2 -->
<div class="popup_img_post">
<div class="modal modal_img fade" id="img2<?php echo $id_post ?>" role="dialog">
  <button type="button" class="close btn_fechar" data-dismiss="modal">&times;</button>
  <div class="modal-dialog">
      
    <div class="modal-content modal_content">
        <div class="modal-body">
          <button type="button" class="close btn_fechar_body" data-dismiss="modal">&times;</button>

          <?php 
              $nome_file2 = "../public/storage/posts/".'2'.$id_post.Str::kebab($rows['titulo_postagem']).'.jpeg';
              $nome_file_png2 = "../public/storage/posts/".'2'.$id_post.Str::kebab($rows['titulo_postagem']).'.png';  
          ?>
          <?php if(file_exists($nome_file2)): ?>
              <img id="img_post1" src="<?php echo e(url('storage/posts/'.'2'.$id_post.Str::kebab($rows['titulo_postagem']).'.jpeg')); ?>">
          <?php elseif(file_exists($nome_file_png2)): ?>
              <img id="img_post1" src="<?php echo e(url('storage/posts/'.'2'.$id_post.Str::kebab($rows['titulo_postagem']).'.png')); ?>">
          <?php endif; ?>
      </div>
    </div>
  </div>
</div>
</div>
<!-- Fim Popup de visualização de imagens2 -->

<!-- Popup de visualização de imagens3 -->
<div class="popup_img_post">
  <div class="modal modal_img fade" id="img3<?php echo $id_post ?>" role="dialog">
      <button type="button" class="close btn_fechar" data-dismiss="modal">&times;</button>
      <div class="modal-dialog">
      <div class="modal-content modal_content">
          <div class="modal-body">
              <button type="button" class="close btn_fechar_body" data-dismiss="modal">&times;</button>
              <?php 
                  $nome_file3 = "../public/storage/posts/".'3'.$id_post.Str::kebab($rows['titulo_postagem']).'.jpeg';
                  $nome_file_png3 = "../public/storage/posts/".'3'.$id_post.Str::kebab($rows['titulo_postagem']).'.png';  
              ?>
              <?php if(file_exists($nome_file3)): ?>
                  <img id="img_post1" src="<?php echo e(url('storage/posts/'.'3'.$id_post.Str::kebab($rows['titulo_postagem']).'.jpeg')); ?>">
              <?php elseif(file_exists($nome_file_png3)): ?>
                  <img id="img_post1" src="<?php echo e(url('storage/posts/'.'3'.$id_post.Str::kebab($rows['titulo_postagem']).'.png')); ?>">
              <?php endif; ?>
          </div>
      </div>
      </div>
  </div>
</div>
<!-- Fim Popup de visualização de imagens3 -->


<!--  Modal de avaliação  -->
<div class="modal fade bd-example-modal-lg" id="post<?php echo $id_post ?>_avaliar" tabindex="-1" role="dialog" id="modalideia" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
          <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <?php if($nivel == 3): ?>
          <form action="<?php echo e(url('/avaliar')); ?>" method="POST">
        <?php elseif($nivel == 2): ?>
          <form action="<?php echo e(url('/avaliar_aval')); ?>" method="POST">
        <?php endif; ?>
            <?php echo csrf_field(); ?>
            <div class="modal-body">
                <div class="notas">
                    <div style="margin: 10px">
                        <label for="inovacao" class="sub">Inovação:</label>
                        <input type="number" name="inovacao" id="inovacao<?php echo e($id_post); ?>" class="nota" step = "0.1" min="0" max="10" required>
                    </div>
                    <div style="margin: 10px">
                        <label for="complexidade" class="sub">Complexidade:</label>
                        <input type="number" name="complexidade" id="complexidade<?php echo e($id_post); ?>" class="nota" step = "0.1" min="0" max="10" required>
                    </div>
                    <div style="margin: 10px">
                        <label for="potencial" class="sub">Potencial de Mercado:</label>
                        <input type="number" name="potencial" id="potencial<?php echo e($id_post); ?>" class="nota" step = "0.1" min="0" max="10"  required>
                    </div>
                </div>
                <div class="media">
                    <div class="center_media">
                        <label for="media" class="sub_media">Média:</label>
                        <input class="nota nota_media" name="media" id="media<?php echo e($id_post); ?>" placeholder="Calculado pelo sistema" readonly>
                        <button type="button" class="calcular" onclick="calcular(<?php echo e($id_post); ?>)"><i class="fas fa-spinner"></i></button>
                    </div>
                    
                </div>
                <div class="coment_avaliador">
                    <label for="comentarios" style="vertical-align: top" class="sub_comentario">Comentários:</label>
                    <textarea name="comentarios" class="comentarios" cols="80" rows="4" placeholder="Digite seu comentário..." required></textarea>
                </div>
                <input type="hidden" name="id_postagem" id="id_postagem1" value="<?php echo e($id_post); ?>">
                <?php if(isset($rows['id'])){?><input type="hidden" name="id_usuario" value="<?php echo e($rows['id']); ?>"><?php }?>
                <input type="hidden" name="id_avaliador" value="<?php echo e(Auth::user()->id); ?>">
            </div>
            <div class="modal-footer-custom grey">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-primary">Finalizar avaliação</button>
            </div>
        </form>
    </div>
  </div>
</div>
<!-- Fim  Modal de avaliação  -->

<?php if(!empty(Session::get('id_postagem'))): ?>
  <script>
    var id_post = "<?php echo Session::get('id_postagem')?>"
    $(function() {
        $('#post'+id_post).modal('show');
    });
  </script>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ToDo\resources\views/layouts/post.blade.php ENDPATH**/ ?>