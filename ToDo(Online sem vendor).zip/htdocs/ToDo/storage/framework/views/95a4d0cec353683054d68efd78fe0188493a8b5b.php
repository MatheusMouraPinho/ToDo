

<?php $user = \Auth::user()->usuario; ?> 

<?php $__env->startSection('content'); ?>
<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-50">
				<form class="login100-form validate-form">
                <div class="login100-form-title p-b-33">Verificação de E-mail</div>

					    <div>
                            <?php if(session('resent')): ?>
                                <div class="alert alert-success" role="alert">
                                    Um link de verificação foi enviado para o seu endereço de e-mail.
                                </div>
                            <?php endif; ?>

                            Olá! <?php  echo $user?>, enviamos um Email de verificação para o email cadastrado.
                            Se você não recebeu o email,
                            <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-linkk p-0 m-0 align-baseline"><b>clique aqui</b></button>
                            </form>
                            para solicitar outro. Lembre-se de verificar a caixa de Spam caso não encontre.
                            <br><br>
                            <a class="txt2 hov1" href="<?php echo e(url('/logout')); ?>">Sair</a>
                        </div>
					</div>
				</form>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.LR', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vol13_3/epizy.com/epiz_26032563/htdocs/ToDo/resources/views/auth/verify.blade.php ENDPATH**/ ?>