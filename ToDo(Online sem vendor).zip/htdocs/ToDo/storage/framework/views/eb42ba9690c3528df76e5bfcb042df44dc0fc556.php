


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card-login">
                <div class="card-cabeca">Aviso</div>

                <div class="card-corpo">
                    Olá! percebemos que você esta utilizando o internet explorer o que pode ocasionar em erros visuais no site, 
                    para acessar o site instale um navegador mais recente.
                    <br><br>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.LR', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vol13_3/epizy.com/epiz_26032563/htdocs/ToDo/resources/views/auth/IE.blade.php ENDPATH**/ ?>