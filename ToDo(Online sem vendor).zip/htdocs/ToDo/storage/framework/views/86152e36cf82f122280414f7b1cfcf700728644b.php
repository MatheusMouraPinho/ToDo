
<?php

use Symfony\Component\Console\Input\Input;

$nivel = Auth::user()->nivel;

?>
<?php $__env->startSection('content'); ?>
<div class="flex justify-content-md-center">
      <div id="area_principal">
        
        <?php if(session('success')): ?>
          <div class="alert alert-success">
            <?php echo e(session('success')); ?>

          </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
          <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

          </div>
        <?php endif; ?>


        <div class="container my-4">
          <h2 id="h1conta">Minha Conta</h2>
        </div>

        <!--||Área de dados do usuário||-->
        <div id="area-dados">
          <div class="card-body text-center">
              
              <?php if($dados['img'] === null): ?>
                <img width="150px" class="img-dados" src="<?php echo e(asset('img/semuser.png')); ?>">
              <?php else: ?>
                <img  alt="<?php echo e(Auth::user()->img_usuarios); ?>" name="img_usuarios" class="img-dados" src="<?php echo e(url('storage/users/'.Auth::user()->img_usuarios)); ?>">
              <?php endif; ?>
            <h3><?php echo e($dados['nome']); ?></h3>
            
            <p><?php echo e($dados['email']); ?></p>
            
              <div id="conteudo-dados">
                <div class="dados-pessoais">
                  <p style="padding: 5px; margin: 0px;">RGM/CPF: <?php echo e($dados['rgm']); ?></p>
                </div>

                <div class="dados-pessoais">
                  <p style="padding: 5px; margin: 0px;">E-mail: <?php echo e($dados['email']); ?></p>
                </div>

                <?php if(is_null($dados['telefone'])): ?>
                  <div class="dados-pessoais">
                    <p style="padding: 5px; margin: 0px;">Telefone/Celular: <span class="font-italic">Não definido</span></p>
                  </div>
                <?php else: ?> 
                  <div class="dados-pessoais">
                    <p id="telefone" style="padding: 5px; margin: 0px;">
                      Celular: <?php echo e($dados['telefone']); ?>

                    </p>
                  </div>
                <?php endif; ?>

                <?php if(empty($dados['instituicao'][0])): ?>
                  <div class="dados-pessoais">
                    <p style="padding: 5px; margin: 0px;">Instituição de Ensino: <span class="font-italic">Não definido</span></p>
                  </div>
                <?php else: ?> 
                  <div class="dados-pessoais">
                    <p style="padding: 5px; margin: 0px;">Instituição: <?php echo e($dados['instituicao']); ?></p>
                  </div>
                <?php endif; ?>

                <?php if(empty($dados['area'][0])): ?>
                  <div class="dados-pessoais">
                    <p style="padding: 5px; margin: 0px;">Área: <span class="font-italic">Não definido</span></p>
                  </div>
                <?php else: ?> 
                  <div class="dados-pessoais">
                    <p style="padding: 5px; margin: 0px;">Área: <?php echo e($dados['area']); ?></p>
                  </div>
                <?php endif; ?>

                <?php if(empty($dados['cidade'][0])): ?>
                  <div class="dados-pessoais">
                    <p style="padding: 5px; margin: 0px;">Região: <span class="font-italic">Não definido</span></p>
                  </div>
                <?php else: ?> 
                  <div class="dados-pessoais">
                    <p style="padding: 5px; margin: 0px;">Região: <?php echo e($dados['cidade']); ?> - <?php echo e($dados['uf'][0]->uf_regiao_estado); ?></p> 
                  </div> 
                <?php endif; ?> 

                
                                          
              </p>
                <a style="margin-left: 2%" href="" data-toggle="modal" data-target="#popup<?php echo e($dados['id']); ?>">Editar perfil</a>
                
              </div>
            </div>
          </div>
      <!--||Fim área de dados||-->

      <!-- Área de ideias do usuario -->
        <?php if(empty($dados['posts'][0])): ?>

          <div id="area_ideias">
            <table id="table_conta">
              <caption>Minhas Ideias</caption>
              <tbody>  
                <tr>
                  <td rowspan="10">
                    <div class="centralizar">
                      <img width="200px" src="<?php echo e(asset('img/denie.png')); ?>">
                      <p class="font-italic">Não foi criada nenhuma ideia</p>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

        <?php else: ?>
          <div id="area_ideias">
            <table id="table_conta">
              <caption>Minhas Ideias</caption>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Data</th>
                  <th>Nome da ideia</th>
                  <th>Situação</th>
                  <th>Detalhes</th>
                </tr>
              </thead>
              <tbody>
                <?php $i = 0?>            
                <?php $__currentLoopData = $dados['posts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($posts->id_postagem); ?></td>
                    <td><?php echo e(date('d/m/Y', strtotime($posts->data_postagem))); ?></td>
                    <td class="abreviar"><?php echo e($posts->titulo_postagem); ?></td>
                    <td> <?php echo e($posts->situacao_postagem); ?> </td>
                    <td>
                      <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#popup<?php echo e($posts->id_postagem); ?>">
                        Visualizar
                      </button>
                    </td>
                    </tr> 
                  
                    <?php echo $__env->make('layouts.post_conta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <div class="card-footer" style="padding: 8px">
              <p id="contagem-ideias">
                <?php echo e($dados['posts']->links()); ?>

              </p>
            </div>
          </div>
        <?php endif; ?>

      <!-- Fim área de ideias do usuario -->

      <!-- Área de edição de dados do usuário -->

      <div class="painel-dados">
        <div class="modal fade id" id="popup<?php echo e($dados['id']); ?>" role="dialog">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>
              <div class="modal-body">
                <form action="<?php echo e(route('profile.update')); ?>" method="POST" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <div class="form-group">
                    <div class="popup-title">
                      <?php if($dados['img'] === null): ?>
                        <img width="150px" name="img_usuarios" class="img" src="<?php echo e(asset('img/semuser.png')); ?>">  
                      <?php else: ?>
                        <img width="200px" alt="<?php echo e(Auth::user()->img_usuarios); ?>" name="img_usuarios" class="img" src="<?php echo e(url('storage/users/'.Auth::user()->img_usuarios)); ?>">
                      <?php endif; ?>
                      <label class="form-control-range">
                        <input type="file" name="img_usuarios" id="file" accept="image/*" multiple onchange="javascript:update()"/>
                        <a name="img_usuarios" class="get-file">Alterar imagem de perfil</a>
                        <div style="text-align: center" id="file-name"></div>
                      </label>
                    </div>

                    <div class="popup-title">
                      <label for="usuario" class="bold subdados">Usuário: </label>
                      <input type="text" class="btn-popup mr-sm-2" value="<?php echo e(Auth::user()->usuario); ?>" placeholder="Usuário" name="usuario">
                    </div>

                    <div class="popup-title">
                      <label for="email" class="bold subdados">E-mail: </label>
                      <input type="text" class="btn-popup mr-sm-2" value="<?php echo e(Auth::user()->email); ?>" name="email" placeholder="E-mail" readonly>
                    </div>

                    <div class="popup-title">
                      <label for="senha" class="bold subdados">Senha: </label>
                      <input type="password" class="btn-popup mr-sm-2" value="<?php echo e(Auth::user()->senha); ?>" name="senha" placeholder="Senha" readonly>
                      <a href="<?php echo e(url('/password/reset')); ?>" class="password">Alterar senha</a>
                    </div>

                    <div class="popup-title">
                      <label for="telefone_usuario" class="bold subdados ">Celular: </label>
                      <input onkeypress="return onlynumber();" minlength="10" maxlength="11" id="telefone_usuario" value="<?php echo e(Auth::user()->telefone_usuario); ?>" type="text" class="btn-popup mr-sm-2 phones" name="telefone_usuario" placeholder="Ex: (11) 11111-1111"/>
                    </div>

                    <hr>

                    <div class="popup-title">
                      <label for="id_instituicao" class="bold subdados">Instituição: </label>
                      <select name="id_instituicao" class="select" title="Selecione uma opção">
                      <option value=""><?php echo e($dados['instituicao']); ?></option>
                        <?php for($a = 0; $a<sizeof($dados['instituicoes']);$a++): ?>
                          <option value="<?php echo e($dados['instituicoes'][$a]->id_instituicao); ?>">
                            <?php echo e($dados['instituicoes'][$a]->nome_instituicao); ?>

                          </option>
                        <?php endfor; ?>
                      </select>
                    </div>

                    <div class="popup-title">
                      <label for="id_area" class="bold subdados">Área: </label>
                      <select name="id_area" class="select" title="Selecione uma opção" class="btn btn-primary">
                        <option value=""><?php echo e($dados['area']); ?></option>
                          <?php for($a = 0; $a<sizeof($dados['areas']);$a++): ?>
                            <option value="<?php echo e($dados['areas'][$a]->id_area); ?>">
                              <?php echo e($dados['areas'][$a]->nome_area); ?>

                            </option>
                          <?php endfor; ?>
                      </select>
                    </div>

                    <div class="popup-title">
                      <label for="id_regiao_cidade" class="bold subdados">Região: </label>
                      <select name="id_regiao_cidade" class="select" title="Selecione uma opção">
                        <option value=""><?php echo e($dados['cidade']); ?></option>
                        <?php for($a = 0; $a<sizeof($dados['cidades']);$a++): ?>
                          <option value="<?php echo e($dados['cidades'][$a]->id_regiao_cidade); ?>">
                            <?php echo e($dados['cidades'][$a]->nome_cidade); ?>

                          </option>
                        <?php endfor; ?>
                      </select>
                    </div>
                    <div class="modal-footer">
                      <input data-toggle="modal" type="submit" class="btn btn-primary dropright" value="Salvar Alterações">
                    </div>  
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Fim área de edição de dados do usuário -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vol1000_4/epizy.com/epiz_26019148/htdocs/ToDo/resources/views/conta.blade.php ENDPATH**/ ?>