

<?php $user = \Auth::user()->usuario; ?> 

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card-login">
                <div class="card-cabeca">Aguardando liberação</div>

                <div class="card-corpo">
                    Olá! <?php  echo $user?>, obrigado por se cadastrar, estamos analisando os seus dados, aguarde a liberação
                    do seu cadastro para acessar o nosso Site!
                    <br><br>
                    <a id="nv" href="<?php echo e(url('/logout')); ?>"> Sair </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.LR', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vol13_3/epizy.com/epiz_26032563/htdocs/ToDo/resources/views/auth/aviso.blade.php ENDPATH**/ ?>